---
name: obsidian-write-back
description: Writes notes and Claude-generated artifacts back to any Obsidian vault. Use when the user asks to save, write, capture, or store something to their vault, or at the end of a session that produced useful outputs. Works with any vault that has a VAULT.md. Triggers on phrases like "save to vault", "write this to Obsidian", "capture this", "save to notes", "put this in my vault", "save everything".
metadata:
  author: Paddy (Prerit Padhy)
  version: 1.0.0
  mcp-server: obsidian
---

# obsidian-write-back

Saves session outputs to an Obsidian vault by reading and following that vault's VAULT.md. Works for any vault — padhy, pp, work, or others.

---

## Step 1: Read VAULT.md

Before anything else:

```
obsidian:file_read(file="VAULT.md")
```

If VAULT.md is missing, stop and tell the user: "I need a VAULT.md to know how this vault is structured. Want me to help you create one?"

From VAULT.md, extract: folder structure, frontmatter schema, tag rules, plugin-owned fields, and write rules.

---

## Step 2: Get Today's Date

Get today's date in `YYYY-MM-DD` format for frontmatter and the daily note backlink.

---

## Step 3: Check Tags

Always run this to discover what tags currently exist across the vault:

```
obsidian:tags_list(all=true)
```

Pick 2–4 that fit the content. If nothing fits, suggest a new one: "I'd suggest a new tag `[x]` — want me to add it?" If yes, just use it in the frontmatter — Obsidian creates it automatically.

---

## Step 4: Get Chat URL

Before writing, ask the user:
> "What is the URL of this chat? Copy it from your browser address bar — I will add it to the source field."

Wait for their response. Use it as the `source` value. If they say skip, leave `source` empty.

---

## Step 5: Write the Note

Write the note as **flowing prose** — like an article or a well-written summary. Do not use rigid sections like "## Documents" or "## Key Points". The note should read naturally and make sense to someone opening it weeks later without needing to re-read this conversation.

Embed file references **inline** where they are contextually relevant, not in a separate section:

> "The W2 from iSeyon ![[W2-2025.pdf]] shows total compensation for the year. The dental receipts ![[scripps-dental-jan.pdf]] may qualify as HSA deductions..."

If the user will be adding file links themselves after the note is created, leave a clear prose placeholder:

> "The supporting documents for this section are linked here — add them with `![[filename]]`."

**Frontmatter:** Use the schema from VAULT.md exactly. Never set plugin-owned fields (e.g. `view-count`).

**Naming:** kebab-case. Date-prefixed if time-sensitive (`2026-02-21-tax-filing.md`), descriptive if evergreen (`gc-pk-i485-status.md`).

---

## Step 6: Write Generated Artifacts (if any)

If the session produced Claude-generated artifacts (Excalidraw diagrams, Canvas files, SVGs, Dataview dashboards), write them to the vault now. See `references/artifacts.md` for the correct format for each type.

Reference each artifact inline in the note where it belongs.

---

## Step 7: Save to Vault

Create the note with `silent=true`, then move it to the correct folder per VAULT.md:

```
obsidian:file_create(name="note-name.md", content="...", silent=true)
obsidian:file_move(file="note-name.md", to="notes/")
```

---

## Step 8: Append Backlink to Daily Note

```
obsidian:daily_append(content="\n- [[note-name]] — one-line description")
```

If today's daily note doesn't exist, create it from the vault template first.

---

## Step 9: Confirm

One or two lines to the user: what was saved, where, what tags were used.

---

## Write Rules

**Always:** Read VAULT.md first. Check tags/ before using any tag. Use `silent=true`. Move notes to the right folder. Append backlink to daily note.

**Never:** Set plugin-owned fields. Create new tag MOC files without asking. Archive or delete without explicit instruction. Modify `templates/`. Overwrite existing notes without explicit instruction.
