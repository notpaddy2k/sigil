# Claude-Generated Artifacts for Obsidian

Reference for writing Claude-generated artifacts directly to an Obsidian vault. Load this file when the session produced a diagram, canvas, or other non-markdown artifact.

---

## Excalidraw

**Extension:** `.excalidraw.md`  
**Destination:** `artifacts/` folder  
**Plugin required:** obsidian-excalidraw-plugin

**File format:**
```
---
excalidraw-plugin: parsed
tags: [excalidraw]
---
==⚠  Switch to EXCALIDRAW VIEW in the MORE OPTIONS menu of this document. ⚠==

%%
**Drawing**
```json
{
  "type": "excalidraw",
  "version": 2,
  "source": "https://excalidraw.com",
  "elements": [...],
  "appState": {
    "gridSize": null,
    "viewBackgroundColor": "#ffffff"
  },
  "files": {}
}
```
%%
```

**Notes:**
- The JSON must be inside a fenced code block inside `%%` comment markers
- Do not use the Obsidian CLI to write this — use `Filesystem:write_file` directly to avoid quote corruption
- After writing, run `obsidian:command_execute(id="app:reload")` to re-index
- Reference in notes as `![[filename.excalidraw.md]]` or `![[filename.excalidraw]]`

---

## Canvas

**Extension:** `.canvas`  
**Destination:** vault root or `notes/`  
**Plugin required:** built-in (Obsidian core)

**File format** (pure JSON):
```json
{
  "nodes": [
    {
      "id": "node1",
      "type": "text",
      "text": "Your content here",
      "x": 0,
      "y": 0,
      "width": 300,
      "height": 100
    },
    {
      "id": "node2",
      "type": "file",
      "file": "notes/your-note.md",
      "x": 400,
      "y": 0,
      "width": 300,
      "height": 100
    }
  ],
  "edges": [
    {
      "id": "edge1",
      "fromNode": "node1",
      "fromSide": "right",
      "toNode": "node2",
      "toSide": "left"
    }
  ]
}
```

**Node types:** `text`, `file`, `link`, `group`  
**Write with:** `Filesystem:write_file` — write raw JSON, no markdown wrapper  
**Reference in notes:** `![[filename.canvas]]`

---

## SVG

**Extension:** `.svg`  
**Destination:** `artifacts/`

**Write with:** `Filesystem:write_file` — write raw SVG markup  
**Reference in notes:** `![[filename.svg]]`

---

## Dataview Dashboard

**Extension:** `.md`  
**Destination:** `notes/`  
**Plugin required:** dataview

Embed Dataview queries inside a regular markdown note:

````markdown
```dataview
TABLE created, maturity, tags
FROM "notes"
WHERE contains(tags, "gc")
SORT created DESC
```
````

No special handling needed — write as a normal markdown file.

---

## Adding New Artifact Types

When a new artifact type is discovered and confirmed working, add it here with:
- Extension and destination
- File format example
- Which write tool to use
- How to reference in notes
